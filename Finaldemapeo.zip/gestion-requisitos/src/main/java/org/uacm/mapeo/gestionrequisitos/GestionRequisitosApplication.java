package org.uacm.mapeo.gestionrequisitos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionRequisitosApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionRequisitosApplication.class, args);
	}

}
