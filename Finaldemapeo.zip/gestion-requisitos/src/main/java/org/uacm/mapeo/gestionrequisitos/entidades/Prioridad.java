package org.uacm.mapeo.gestionrequisitos.entidades;

public enum Prioridad {
    alta, media, baja;
}