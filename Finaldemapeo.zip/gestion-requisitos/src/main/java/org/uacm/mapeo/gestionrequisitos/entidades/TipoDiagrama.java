package org.uacm.mapeo.gestionrequisitos.entidades;

public enum TipoDiagrama {
    casos_de_uso, secuencia, clases, paquetes, actividad,
    estados, componentes, despliegue, arquitectura
}
