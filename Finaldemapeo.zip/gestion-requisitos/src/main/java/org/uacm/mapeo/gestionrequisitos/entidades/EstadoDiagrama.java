package org.uacm.mapeo.gestionrequisitos.entidades;

public enum EstadoDiagrama {
    borrador, aprobado, obsoleto
}