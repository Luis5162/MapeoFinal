package org.uacm.mapeo.gestionrequisitos.entidades;

public enum EstadoRequisito {
    activo, inactivo
}
